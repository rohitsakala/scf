// +build OMIT

package main

import "fmt"

func main() {
	// START OMIT
	fmt.Printf("%s", "Hello, 世界")
	// STOP OMIT
}
